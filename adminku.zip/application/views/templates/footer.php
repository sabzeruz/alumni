
</div> 
</div>
<footer>
    <div class="footer clearfix mb-0 mt-3 text-muted">
        <div class="float-start">
            <p>2022 &copy; Sabzeruz</p>
        </div>
        <div class="float-end">
            <p>Modified with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a href="https://github.com/sabzeruz">Sabzeruz</a></p>
        </div>
    </div>
</footer>


<!-- <script>
        window.onload = (event) => {
  let myAlert = document.querySelectorAll('.toast')[0];
    let bsAlert = new bootstrap.Toast(myAlert);
    bsAlert.show();
};
    </script> -->
    <script type="text/javascript">
     

    </script>

<script src="<?= base_url('assets/js/bootstrap.js') ?>"></script>
<script src="<?= base_url('assets/js/app.js') ?>"></script>

<script src="<?= base_url('assets/extensions/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
<script src="<?= base_url('assets/js/pages/datatables.js') ?>"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>





</body>

</html>